package net.mcreator.rotnblocks.procedure;

import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;

import net.mcreator.rotnblocks.block.BlockWeatheredCopperBlock;
import net.mcreator.rotnblocks.ElementsRotnBlocksMod;

import java.util.Map;

@ElementsRotnBlocksMod.ModElement.Tag
public class ProcedureSemiWheateredCopperBlockUpdateTick extends ElementsRotnBlocksMod.ModElement {
	public ProcedureSemiWheateredCopperBlockUpdateTick(ElementsRotnBlocksMod instance) {
		super(instance, 13);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure SemiWheateredCopperBlockUpdateTick!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure SemiWheateredCopperBlockUpdateTick!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure SemiWheateredCopperBlockUpdateTick!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure SemiWheateredCopperBlockUpdateTick!");
			return;
		}
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		world.setBlockState(new BlockPos((int) x, (int) y, (int) z), BlockWeatheredCopperBlock.block.getDefaultState(), 3);
	}
}
